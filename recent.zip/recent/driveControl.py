rSize = 300

def driveControl(rot, distance, driveRot):	#need to define max distances
	distance = abs(distance)
	if(abs(rot) > 25):
                print("a")
                rotVel = 100 * rot / abs(rot)
	elif(rot == 0):
                print("b")
                rotVel = 0
	else:
		rotVel = (rot*3) + (25 * rot / abs(rot))
	
	if((distance - rSize) < 100 and abs(rot) > 25):	#max distances
		driveVel = 100
	elif(abs(distance - rSize) < 75):
		driveVel = (distance - rSize) * 4/3
	else:
		driveVel = 100
		
	return rotVel, abs(int(driveVel))