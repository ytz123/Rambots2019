# import the necessary packages
from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2
import numpy as np
import math
import findBall as fb
import driveControl as dc
import rotate
import arduinoCom as ac
 
# initialize the camera and grab a reference to the raw camera capture
camera = PiCamera()
camera.resolution = (1378, 768)
camera.framerate = 32
rawCapture = PiRGBArray(camera, size=(1378, 768))

zeroRot = 0
port = ac.init()
dribble = '1'

#zeroRot, img = rotate.rotate(img, w, h)
#print("rotate")

# allow the camera to warmup
time.sleep(0.1)
# capture frames from the camera
for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
	# grab the raw NumPy array representing the image - this array
	# will be 3D, representing the width, height, and # of channels
	img = frame.array
 
	# show the frame
	w, h, c = img.shape	#gets hieght and with of picture
	print("cam")
	r, theta = fb.findBall(img, w, h)
	print("fb")
        #rot = zeroRot + theta
	
	rotVel, driveVel = dc.driveControl(theta, r, theta)
	print(driveVel)
	info = ac.send("/dev/ttyACM0", int(theta), int(driveVel), int(rotVel/1.5), ord(dribble), 0, 1)
	print("ac")
        
	# if the `q` key was pressed, break from the loop
	#if key == ord("q"):
#		break