import math
import cv2
import numpy as np
import cornerDetect as cd
import rotate as ri

def rotateImage(image, image_center, angle):
    rot_mat = cv2.getRotationMatrix2D(image_center, angle, 1.0)
    result = cv2.warpAffine(image, rot_mat, image.shape[1::-1], flags = cv2.INTER_LINEAR)
    return result

def rotate(img, width, height):												#find degrees to rotate to line blue and yellow goals horizontally
	bbx, bby, btx, bty = cd.cornerDetect(120, img, False)					#blue
	ybx, yby, ytx, yty = cd.cornerDetect(30, img, False)					#yellow
	m = ((bty + bby)/2 - (yty + yby)/2)/((btx + bbx)/2 - (ytx + ybx)/2)		#slope of line between top of two goals #want to make vertical
	rot = math.degrees(math.atan(m) - math.atan(0))							#might be rotating in wrong direction
	#img = ri.rotateImage(img, (width/2, height/2), rot)
	#bbx, bby, btx, bty = cd.cornerDetect(120, img, False)					#blue
	#ybx, yby, ytx, yty = cd.cornerDetect(30, img, False)					#yellow
	if (bby < yby):															#if blue is to the right rotate by 180
		rot = rot + 180
#		img = ri.rotateImage(img, (width/2, height/2), 180)
	return rot % 360, img
	

	