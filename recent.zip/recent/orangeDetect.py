import cv2
import numpy as np


def orangeDetect(img): 							#white is true if looking for white. if so h doesn't matter
        
        coords = None
	#Converts images from BGR to HSV
        cv2.imwrite("img.jpg", img)
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        cv2.imwrite("hsv.jpg", hsv)
        lower = np.array([0, 90, 90],np.uint8) #-15,60,60
        upper = np.array([3, 255, 255],np.uint8)#+15,255,255
        
        lower1 = np.array([175, 90, 90],np.uint8) #-15,60,60
        upper1 = np.array([180, 255, 255],np.uint8)

	#This creates a mask of the correct coloured  
	#objects found in the frame.
        mask = cv2.inRange(hsv, lower, upper)
        mask1 = cv2.inRange(hsv, lower1, upper1)
        mask = cv2.bitwise_or(mask, mask1)
        cv2.imwrite("mask.jpg", mask)
#        cv2.imshow("mask", mask)
	#Detects and Draws Corners
#        dst = cv2.cornerHarris(mask,2,3,.04)
#        corners = cv2.dilate(dst,None)
	
        contours,hierarchy = cv2.findContours(mask, cv2.RETR_LIST , cv2.CHAIN_APPROX_NONE)

        if len(contours) != 0:
            # the contours are drawn here
            cv2.drawContours(mask, contours, -1, 255, 3)
            #find the biggest area of the contour
            coords = max(contours, key = cv2.contourArea)
        
	#Finds Corners and Parses Data
#        coords = cv2.findNonZero(mask)
        if coords is not None:
            bottom = str(coords[-1]).strip("[]")
            bottom = str(bottom).strip()
            BX,BY = str(bottom).split()
            top = str(coords[0]).strip("[]")
            top = str(top).strip()
            TX,TY = str(top).split()
            return int(BX), int(BY), int(TX), int(TY)
        else:
            return 820,616,820,616