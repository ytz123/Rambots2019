import cv2
import numpy as np

def cornerDetect(H, img, white): 							#white is true if looking for white. if so h doesn't matter

	#Converts images from BGR to HSV
        cv2.imwrite("img.jpg", img)
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        cv2.imwrite("hsv.jpg", hsv)
        if not white:
                lower = np.array([H-5, 110, 80],np.uint8) #-15,60,60
                upper = np.array([H+5, 255, 255],np.uint8)#+15,255,255
        else:
                lower = np.array([0, 0, 200],np.uint8)
                upper = np.array([179, 255, 220],np.uint8)
  
	#This creates a mask of the correct coloured  
	#objects found in the frame.
        mask = cv2.inRange(hsv, lower, upper)
        cv2.imwrite("mask.jpg", mask)
	#Detects and Draws Corners
#        dst = cv2.cornerHarris(mask,2,3,.04)
#        corners = cv2.dilate(dst,None)
	
	#Finds Corners and Parses Data
        coords = cv2.findNonZero(mask)
        bottom = str(coords[-1]).strip("[]")
        bottom = str(bottom).strip()
        BX,BY = str(bottom).split()
        top = str(coords[0]).strip("[]")
        top = str(top).strip()
        TX,TY = str(top).split()
        return int(BX), int(BY), int(TX), int(TY)