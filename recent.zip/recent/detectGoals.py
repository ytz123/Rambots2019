import rotate as r
import cornerDetect as cd

def detectGoals(goalColor, img, w, h):
    rot, img = r.rotate(img, w, h)
    if (goalColor = 1): #blue
        rot = (rot + 180) % 360
        bx, by, tx, ty = cd.cornerDetect(120, img, False)
    else:
        bx, by, tx, ty = cd.cornerDetect(30, img, False)