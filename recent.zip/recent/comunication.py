import serial
import sys
import glob

def send(port, angle, vel, rotVel, four, five, sendInfo):
	#Combines Data
	info = bytes(str(angle) + "," + str(vel) + "," + str(rotVel) + "," + str(four) + "," + str(five) + "," + str(sendInfo) + '\n', 'utf-8')
	#Output to Arduino
	print(info)
	ser = serial.Serial(port, baudrate = 9600)	#(serial_ports()[0])
	ser.flushInput()
	ser.write(info)	# write a string
	print(sendInfo)
	if(sendInfo == 1):
            if ser.inWaiting() > 0:
                x = ser.read()
                print(x)
                ser.close()									# close port
                return x
	ser.close()									# close port
	

def init():
    if sys.platform.startswith('win'):
        ports = ['COM%s' % (i + 1) for i in range(256)]
    elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
        # this excludes your current terminal "/dev/tty"
        ports = glob.glob('/dev/tty[A-Za-z]*')
    elif sys.platform.startswith('darwin'):
        ports = glob.glob('/dev/tty.*')
    else:
        raise EnvironmentError('Unsupported platform') 
    result = []
    for port in ports:
        try:
            s = serial.Serial(port)
            s.close()
            result.append(port)
        except (OSError, serial.SerialException):
            pass
    if __name__ == '__main__':
        print("Port List: " + serial_ports())
        print("Reccomended Port: " + serial_ports()[0])
    return result

#serial_ports()
#port = serial_ports()[0] #This is in case you forget to set the port for ArduinoCom
a = send("/dev/ttyACM0",0,0,0,0,0,1)
print(a)
