import numpy as np
import cv2
import math
import os

#build map for unwarping
#wi and hi are width and height of input picture,wo and ho are width and height of output.
#the rest of the variables are the same as above
def Map(Wi,Hi,Wo,Ho,R1,R2,Cx,Cy):
    xmap = np.zeros((int(Ho), int(Wo)), np.float32)
    ymap = np.zeros((int(Ho), int(Wo)), np.float32)
    for y in range(0, Ho-1):
        for x in range(0, Wo-1):				#loop through entire output image to create map
            r = y + R1							#since y < R2-R1 becuase that is Ho r will be between R2 and R1 so it will be in the donut
            theta = x/R2						#this is theta in radians becuase R2 = 1 radians
            Xi = Cx + r * math.sin(theta)		#convert polar to cartesian and add Cx becuase this will be based off center of donut not actual coordinates 
            Yi = Cy + r * math.cos(theta)
            #convert polar to cartesian and add Cy becuase this will be based off center of donut not actual coordinates
            xmap[y, x] = int(Xi)
            ymap[y, x] = int(Yi)
    return xmap, ymap

def unwarp(rawImg, xmap, ymap, Ho, Wo):
    img = np.zeros((int(Ho), int(Wo), 1), np.uint8)			#creates empty map (unsure if necessary)
    img = cv2.remap(rawImg, xmap, ymap, cv2.INTER_LINEAR)	#unwarps the raw image
    img = img[0:Ho, 0:Wo]
    return img

def getMap(Wi,Hi,Wo,Ho,R1,R2,Cx,Cy):
    if not os.path.isfile("maps.npz"):						#check if map exists if not then creates map       
        xmap, ymap = Map(Wi,Hi,Wo,Ho,R1,R2,Cx,Cy)
        np.savez("maps.npz", xmap = xmap, ymap = ymap)
    else:													#if map exists then read from save file
        maps = np.load("maps.npz")
        xmap, ymap = maps["xmap"], maps["ymap"]
    return xmap, ymap
    
def circleCenter(x1, y1, x2, y2, x3, y3):					# 3 points on circle
    m1 = -(x1 - x2) / (y1 - y2)								#negative reciprical of the slope of a chord of the circle
    m2 = -(x2 - x3) / (y2 - y3)								#negative reciprical of the slope of a chord of the circle
    b1 = ((y1 + y2) / 2) - (m1 * (x1 + x2) / 2)				#if y=mx+b the b=y-mx, x and y are the coordinates of the midpoint of the chord
    b2 = ((y2 + y3) / 2) - (m2 * (x2 + x3) / 2)				#if y=mx+b the b=y-mx, x and y are the coordinates of the midpoint of the chord
    x = (b2 - b1) / (m1 - m2)								#y=m1x+b1 and y=m2x+b2 so m1x+b1=m2x+b2 so m1x-m2x=b2-b1 m1x-m2x is x(m1-m2) divide both sides by (m1-m2)
    y = m1*x+b1												#y=mx+b of either perpendicular bisector
    r = math.sqrt(((x - x1)*(x -x1)) + ((y - y1)*(y - y1)))	#distance formula
    return x,y,r
	
#H is hue of color to look for
#returns highest and lowest point of that color
def cornerDetect(H, img, white): 							#white is true if looking for white. if so h doesn't matter

	#Converts images from BGR to HSV 
	hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
	if not white:
		lower = np.array([H-20, 60, 60])
		upper = np.array([H+20, 255, 255])
	else:
		lower = np.array([0, 0, 200])
		upper = np.array([179, 255, 220])
  
	#This creates a mask of the correct coloured  
	#objects found in the frame. 
	mask = cv2.inRange(hsv, lower, upper)

	#Detects and Draws Corners
	dst = cv2.cornerHarris(mask,2,3,.04)
	corners = cv2.dilate(dst,None)
	
	#Finds Corners and Parses Data
	coords = cv2.findNonZero(corners)
	print(';;;',coords[-1],';;;')
	bottom = str(coords[-1]).strip("[]")
	bottom = str(bottom).strip()
	BX,BY = str(bottom).split()
	top = str(coords[0]).strip("[]")
	top = str(top).strip()
	TX,TY = str(top).split()
	
	return int(BX), int(BY), int(TX), int(TY)
	
def imgSplit(x1, x2, img, Ho, Wo):							#Takes unwrapped img and splits into two divided at x1 and x2. x1 < x2 is a must
	x = sorted([x1, x2])
	img1 = img[0:x[0], 0:Ho]
	img2 = img[x[0]:x[1], 0:Ho]
	img3 = img[x[1]:Wo, 0:Ho]
	img1 = np.concatenate((img3, img1), axis = 0)
	return (img1, img2) if x[0] == x1 else (img2, img1)
	
def findRot(img, Ho, Wo):
	bbx, bby, btx, bty = cornerDetect(120, img, False)									#finds highest blue
	ybx, yby, ytx, yty = cornerDetect(30, img, False)									#finds highest yellow
	img1, img2 = imgSplit(btx, ytx, img, Ho, Wo)	#splits img into area between blue and yellow goals
	w1bx, w1by, w1tx, w1ty = cornerDetect(0, img1, True)								#finds closest white lines
	w2bx, w2by, w2tx, w2ty = cornerDetect(0, img2, True)
	if((btx + w1bx) - (ytx + w2bx) < Wo/2 + 10 and (btx + w1bx) - (ytx + w2bx) > Wo/2 -10):	#checks if closest white lines are on opposite sides of img within margin of error of 20 pixels
		return x1 + w2bx																#calculates where zero degrees of rotation is (right angle with white line after blue goal in unwrapped img)

def detectBall(img):
	#set ranges of orange and green to look for
	hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
	lowerOrange = np.array([0, 60, 60])
	upperOrange = np.array([30, 255, 255])
	lowerGreen = np.array([45, 60, 60])
	upperGreen = np.array([75, 255, 255])
	 
	#create masks of orange and green and both
	orangeMask = cv2.inRange(hsv, lowerOrange, upperOrange)
	greenMask = cv2.inRange(hsv, lowerGreen, upperGreen)
	bothMask = cv2.bitwise_or(orangeMask, greenMask)
	
	#detect corners of masks
	orangeDst = cv2.cornerHarris(orangeMask, 2, 3, .04)
	orangeCorners = cv2.dilate(orangeDst, None)
	bothDst = cv2.cornerHarris(bothMask, 2, 3, .04)
	bothCorners = cv2.dilate(bothDst, None)
	
	#find edge on orange and not on both
	ballEdgeOnField = cv2.bitwise_and(orangeCorners, cv2.bitwise_not(bothCorners))
	
	#get list of cordinates
	coords = cv2.findNonZero(ballEdgeOnField)
	
	#parse coords
	frst = str(coords[0]).strip("[]")
	scnd = str(coords[int(len(coords)/2)]).strip("[]")
	thrd = str(coords[-1]).strip("[]")
	
	frst = frst.strip()
	scnd = scnd.strip()
	thrd = thrd.strip()
	
	x1, y1 = frst.split()
	x2, y2 = scnd.split()
	x3, y3 = thrd.split()
	
	#calculate center of circle and return it
	return circleCenter(int(x1), int(y1), int(x2), int(y2), int(x3), int(y3))
	
#def findLoc(img, zeroRot, Wo):
	