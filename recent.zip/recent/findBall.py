import cv2
import math
import orangeDetect as od


def findBall(img, width, height):
	bx, by, tx, ty = od.orangeDetect(img)					#orange
	x = ((bx + tx)/2) - width/2
	y = ((by + ty)/2) - height/2
	r = math.sqrt(x*x + y*y)
	theta = math.atan(y/x)
	return r, theta*180/math.pi
	
