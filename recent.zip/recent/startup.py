from subprocess import call
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(1, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) # REPLACE NUMBERS
GPIO.setup(2, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) # WITH PIN
GPIO.setup(3, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) # USED ON
GPIO.setup(4, GPIO.IN, pull_up_down=GPIO.PUD_DOWN) # THE BOARD
#check switch if on run code if not then do nothing
if GPIO.input(1) == 1:
    #PUT CODE 1 HERE
    
	#check switch set var goalColor as blue or yellow
    if GPIO.input(3) == True:
        goalColor = "blue"
    else:
        goalColor = "yellow"
	
    #check switch if on run one code if not run other code
    if GPIO.input(2) == True:
        print("TEMP") #Replace this line with code 2
    else:
        print("TEMP") #Replace this line with code 3

    #button to PROPERLY shutdown pi
    if GPIO.input(4) == True:
        call("sudo shutdown now", shell = True)
