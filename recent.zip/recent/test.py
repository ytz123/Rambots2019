import cv2
from picamera import PiCamera
from picamera.array import PiRGBArray
import time
import numpy as np
import math
import findBall as fb
import driveControl as dc
import rotate
import comunication as com

cam = PiCamera()
cam.resolution = (1640, 1232)

time.sleep(0.1)
zeroRot = 0
#port = ac.init()
dribble = '1'
kernel = np.ones((5,5),np.float32)/25

#zeroRot, img = rotate.rotate(img, w, h)
#print("rotate")

try:
#    while True:
        rawImg = PiRGBArray(cam, size=(1640, 1232))
        cam.capture(rawImg, format = "bgr")    #gets picture
        img = rawImg.array
        w, h, c = img.shape	#gets hieght and with of picture
#        print("cam")
        cv2.circle(img,(820,626), 280, (0,0,0), -1)
        img = cv2.filter2D(img,-1,kernel)
        r, theta = fb.findBall(img, w, h)
#        print("fb")
        #rot = zeroRot + theta
        theta = -theta
        theta = theta % 360
        print(theta)
        rotVel, driveVel = dc.driveControl(theta, r, theta)
        print(rotVel)
        dribble = com.send("/dev/ttyACM0", int(theta), 20, 0, 0, 0, 1)
        while True:
            a=1
        
except KeyboardInterrupt:
    ac.send("/dev/ttyACM0", 0, 0, 0, 0, 0, 0)
    pass
