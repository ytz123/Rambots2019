import cv2
import imageProcessing as ip
from picamera import PiCamera
from picamera.array import PiRGBArray
import time
import numpy as np
import math
#from picamera.array import PiRGBAraray

cam = PiCamera()
cam.resolution = (3280, 2464)
rawImg = PiRGBArray(cam, size=(3280, 2464))
#rawImg = np.zeros((768, 1376, 3), np.uint8)
time.sleep(1)

Cx = 714				#center of donut x
Cy = 431				#center of donut y
R1 = 0				#radius of donut hole
R2 = 400
#radius of the donut (including the hole)
Ho = R2-R1					#hieght of output (radius of the part of the donut with pixels)
Wo = int(2*(R2)*math.pi)	#width of the output (circumference of the middle of pixels (average of radii times two for diameter times pi))
zeroRot = 0

cam.capture(rawImg, format = "bgr")    #gets picture
img = rawImg.array
Wi,Hi,c = img.shape	#gets hieght and with of picture
print(Hi, Wi)
#cv2.imwrite("raw.jpg", rawImg)
#np.frombuffer(rawImg, dtype = np.uint8, count = Hi * Wi).reshape(Hi, Wi)	#converts rawImg to numpy array (not sure if works)
cv2.imwrite("rawImg.jpg", img)											#saves rawImg (for testing purposes)
xmap, ymap = ip.getMap(Wi,Hi,Wo,Ho,R1,R2,Cx,Cy)								#gets maps to unwrap
img = ip.unwarp(img, xmap, ymap, Ho, Wo)									#gets unwraped img
#stretch = cv2.resize(img, (0,0), fx = 1, fy = .5)
cv2.imwrite("unwrapped_image.jpg", img)										#saves img (for testing purposes)

#zeroRot = ip.findRot(img, Ho, Wo) or zeroRot
x, y, r = ip.detectBall(img)
print(x,y,r)

